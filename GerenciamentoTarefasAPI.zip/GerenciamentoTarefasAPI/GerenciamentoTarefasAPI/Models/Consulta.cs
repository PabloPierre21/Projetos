﻿using System;
using System.Linq;
using GerenciadorTarefasAPI.Models;

namespace GerenciadorTarefasAPI
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new TarefasContext())
            {
                var tarefas = db.Tarefas.ToList();
                foreach (var tarefa in tarefas)
                {
                    Console.WriteLine($"Tarefa {tarefa.Id}: {tarefa.Nome} - {tarefa.Descricao} - {tarefa.DataConclusao} - {tarefa.Prioridade} - {tarefa.Status}");
                }
            }
        }
    }
}