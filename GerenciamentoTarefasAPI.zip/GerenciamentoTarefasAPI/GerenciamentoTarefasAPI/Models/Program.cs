﻿using Microsoft.EntityFrameworkCore;

namespace GerenciamentoTarefasAPI.Models
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                })
                .ConfigureServices(services =>
                {
                    var options = new DbContextOptionsBuilder<TarefasContext>()
                        .UseSqlServer("Server=tcp:servertestedev.database.windows.net,1433;Initial Catalog=TarefasBanco;Persist Security Info=False;User ID=admin_teste;Password=t3st32023#;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;")
                        .Options;

                    using (var db = new TarefasContext(options))
                    {
                        var tarefaExistente = db.Tarefas.FirstOrDefault(t => t.Nome == "Tarefa 1");

                        if (tarefaExistente == null)
                        {
                            var tarefa = new Tarefa
                            {
                                Nome = "Tarefa 1",
                                Descricao = "Descrição da Tarefa 1",
                                DataConclusao = DateTime.Now.AddDays(7),
                                Prioridade = 1,
                                Status = "A fazer"
                            };

                            db.Tarefas.Add(tarefa);
                            db.SaveChanges();
                        }

                        // Consulta todas as tarefas armazenadas
                        var tarefas = db.Tarefas.ToList();

                        foreach (var item in tarefas)
                        {
                            Console.WriteLine("ID: " + item.Id);
                            Console.WriteLine("Nome: " + item.Nome);
                            Console.WriteLine("Descrição: " + item.Descricao);
                            Console.WriteLine("Data de conclusão: " + item.DataConclusao);
                            Console.WriteLine("Prioridade: " + item.Prioridade);
                            Console.WriteLine("Status: " + item.Status);
                            Console.WriteLine("---------------");
                        }
                    }
                });
    }
}



