using Microsoft.EntityFrameworkCore;

namespace GerenciamentoTarefasAPI.Models
{
    public class TarefasContext : DbContext
    {
        public TarefasContext(DbContextOptions<TarefasContext> options) : base(options)
        {
        }

        public DbSet<Tarefa>? Tarefas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Tarefa>()
                .HasKey(t => t.Id);
        }
    }
}