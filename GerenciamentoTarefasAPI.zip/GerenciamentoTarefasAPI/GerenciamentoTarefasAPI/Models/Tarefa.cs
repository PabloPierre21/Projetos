using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GerenciamentoTarefasAPI.Models
{
    public class Tarefa
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; } // Identificador único da tarefa
        public string Nome { get; set; } // Nome da tarefa
        public string Descricao { get; set; } // Descrição da tarefa
        public DateTime DataConclusao { get; set; } = DateTime.Now.AddDays(7); // Data de conclusão da tarefa
        public int Prioridade { get; set; } // Prioridade da tarefa
        public string Status { get; set; } // Status da tarefa (concluída, pendente, etc.)
    }
}
