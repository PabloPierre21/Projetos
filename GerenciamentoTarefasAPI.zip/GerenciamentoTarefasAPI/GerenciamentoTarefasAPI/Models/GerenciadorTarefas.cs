// Importação das bibliotecas necessárias

using Microsoft.Data.SqlClient;

namespace GerenciamentoTarefasAPI.Models;

public class GerenciadorTarefas
{
    private string _connectionString;
    private List<Tarefa> _tarefas;

    // Construtor da classe GerenciadorTarefas que recebe a string de conexão como parâmetro

    public GerenciadorTarefas(string connectionString)
    {
        _connectionString = connectionString;
    }

    // Método responsável por criar uma nova tarefa no banco de dados
    public void CriarTarefa(Tarefa tarefa)
    {
        using (SqlConnection connection = new SqlConnection(_connectionString))
        {
            // Definição da query SQL para inserir uma nova tarefa no banco de dados
            string query = "INSERT INTO Tarefas (Nome, Descricao, DataConclusao, Prioridade, Status) " +
                           "VALUES (@Nome, @Descricao, @DataConclusao, @Prioridade, @Status)";

            // Criação do objeto SqlCommand e definição dos parâmetros da query SQL
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Nome", tarefa.Nome);
            command.Parameters.AddWithValue("@Descricao", tarefa.Descricao);
            command.Parameters.AddWithValue("@DataConclusao", tarefa.DataConclusao);
            command.Parameters.AddWithValue("@Prioridade", tarefa.Prioridade);
            command.Parameters.AddWithValue("@Status", tarefa.Status);

            // Abertura da conexão com o banco de dados e execução da query SQL
            connection.Open();
            command.ExecuteNonQuery();
        }
    }
// Método responsável por listar todas as tarefas do banco de dados
    public List<Tarefa> ListarTarefas()
    {
        // Criação de uma lista vazia para armazenar as tarefas
        List<Tarefa> tarefas = new List<Tarefa>();

        using (SqlConnection connection = new SqlConnection(_connectionString))
        {
            // Definição da query SQL para selecionar todas as tarefas do banco de dados
            string query = "SELECT Id, Nome, Descricao, DataConclusao, Prioridade, Status FROM Tarefas";
            
            // Criação do objeto SqlCommand e execução da query SQL
            SqlCommand command = new SqlCommand(query, connection);

            connection.Open();

            SqlDataReader reader = command.ExecuteReader();
            
            // Loop para iterar sobre todos os registros retornados pela query SQL
            while (reader.Read())
            {
                // Criação de um objeto Tarefa e atribuição dos valores dos campos do registro
                Tarefa tarefa = new Tarefa();
                tarefa.Id = reader.GetInt32(0);
                tarefa.Nome = reader.GetString(1);
                tarefa.Descricao = reader.GetString(2);
                tarefa.DataConclusao = reader.GetDateTime(3);
                tarefa.Prioridade = reader.GetInt32(4);
                tarefa.Status = reader.GetString(5);

                tarefas.Add(tarefa);
            }
        }
        
        // Retorno da lista de tarefas
        return tarefas;
    }
    //o método conecta ao banco de dados, executa uma consulta SQL para obter a tarefa ID  e retorna um objeto Tarefa 
    public Tarefa ObterTarefaPorId(int id)
    {
        using (SqlConnection connection = new SqlConnection(_connectionString))
        {
            // Definição da query SQL para selecionar a tarefa com o ID especificado
            string query = "SELECT Id, Nome, Descricao, DataConclusao, Prioridade, Status FROM Tarefas WHERE Id = @Id";

            // Criação do objeto SqlCommand e definição do parâmetro da query SQL
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Id", id);

            connection.Open();

            SqlDataReader reader = command.ExecuteReader();

            if (reader.Read())
            {
                // Criação de um objeto Tarefa e atribuição dos valores dos campos do registro
                Tarefa tarefa = new Tarefa();
                tarefa.Id = reader.GetInt32(0);
                tarefa.Nome = reader.GetString(1);
                tarefa.Descricao = reader.GetString(2);
                tarefa.DataConclusao = reader.GetDateTime(3);
                tarefa.Prioridade = reader.GetInt32(4);
                tarefa.Status = reader.GetString(5);

                return tarefa;
            }
            else
            {
                // Caso não exista nenhuma tarefa com o ID especificado, retorna exception 
                throw new Exception($"Não foi encontrada uma tarefa com o ID {id}");
            }
        }
    }
    
    
    // Método responsável por atualizar os dados de uma tarefa no banco de dados
    public void AtualizarTarefa(Tarefa tarefa)
    {
        using (SqlConnection connection = new SqlConnection(_connectionString))
        {
            // Definição da query SQL para atualizar os dados de uma tarefa no banco de dados
            string query = "UPDATE Tarefas SET Nome = @Nome, Descricao = @Descricao, DataConclusao = @DataConclusao, Prioridade = @Prioridade, " +
                           "Status = @Status WHERE Id = @Id";

            // Adiciona os parâmetros à query SQL
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Nome", tarefa.Nome);
            command.Parameters.AddWithValue("@Descricao", tarefa.Descricao);
            command.Parameters.AddWithValue("@DataConclusao", tarefa.DataConclusao);
            command.Parameters.AddWithValue("@Prioridade", tarefa.Prioridade);
            command.Parameters.AddWithValue("@Status", tarefa.Status);
            command.Parameters.AddWithValue("@Id", tarefa.Id);

            connection.Open();
            command.ExecuteNonQuery();
        }
    }
    
    public void AtualizarTarefaStatus(int id, string status)
    {
        Tarefa tarefa = ObterTarefaPorId(id);

        if (tarefa == null)
        {
            throw new Exception($"Não foi encontrada uma tarefa com o ID {id}");
        }

        tarefa.Status = status;
        AtualizarTarefa(tarefa);
    }
    
    public List<Tarefa> PesquisarTarefas(string filtro)
    {
        // Cria uma lista para armazenar as tarefas que correspondem ao filtro
        List<Tarefa> tarefasFiltradas = new List<Tarefa>();

        // Percorre todas as tarefas da lista de tarefas
        foreach (Tarefa tarefa in _tarefas)
        {
            // Verifica se o nome ou descrição da tarefa contém o filtro
            if (tarefa.Nome.Contains(filtro) || tarefa.Descricao.Contains(filtro))
            {
                // Adiciona a tarefa filtrada na lista de tarefas filtradas
                tarefasFiltradas.Add(tarefa);
            }
        }

        // Retorna a lista de tarefas filtradas
        return tarefasFiltradas;
    }
    
    // Método para buscar a tarefa com ID na lista de tarefas e, se encontrada, define sua prioridade 
    public void DefinirPrioridade(int idTarefa, int prioridade)
    {
        Tarefa tarefa = _tarefas.FirstOrDefault(t => t.Id == idTarefa);

        if (tarefa != null)
        {
            tarefa.Prioridade = prioridade;
        }
        else
        {
            throw new ArgumentException($"Não foi encontrada uma tarefa com o ID {idTarefa}.");
        }
    }

  
    // Método responsável por excluir uma tarefa existente no banco de dados a partir do seu ID
    public void ExcluirTarefa(int id)
    {
        using (SqlConnection connection = new SqlConnection(_connectionString))
        {
            string query = "DELETE FROM Tarefas WHERE Id = @Id";

            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Id", id);

            connection.Open();
            command.ExecuteNonQuery();
        }
    }
}