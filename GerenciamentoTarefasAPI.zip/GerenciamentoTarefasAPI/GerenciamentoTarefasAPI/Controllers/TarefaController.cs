using GerenciamentoTarefasAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace GerenciamentoTarefasAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TarefaController : ControllerBase
    {
        // Injetando a dependência do gerenciador de tarefas
        private readonly GerenciadorTarefas _gerenciador;

        public TarefaController(GerenciadorTarefas gerenciador)
        {
            _gerenciador = gerenciador;
        }

        // Cria uma nova tarefa
        [HttpPost]
        public IActionResult CriarTarefa([FromBody] Tarefa tarefa)
        {
            _gerenciador.CriarTarefa(tarefa);
            return Ok();
        }

        // Lista todas as tarefas cadastradas
        [HttpGet]
        public IActionResult ListarTarefas()
        {
            List<Tarefa> tarefas = _gerenciador.ListarTarefas();
            return Ok(tarefas);
        }

        // Busca uma tarefa pelo seu ID
        [HttpGet("{id}")]
        public IActionResult ObterTarefaPorId(int id)
        {
            try
            {
                Tarefa tarefa = _gerenciador.ObterTarefaPorId(id);
                return Ok(tarefa);
            }
            catch (Exception ex)
            {
                return BadRequest($"Ocorreu um erro ao buscar a tarefa: {ex.Message}");
            }
        }

        // Atualiza uma tarefa existente pelo seu ID
        [HttpPut("{id}")]
        public IActionResult AtualizarTarefa(int id, [FromBody] Tarefa tarefa)
        {
            tarefa.Id = id;
            _gerenciador.AtualizarTarefa(tarefa);
            return Ok();
        }

        // Exclui uma tarefa existente pelo seu ID
        [HttpDelete("{id}")]
        public IActionResult ExcluirTarefa(int id)
        {
            _gerenciador.ExcluirTarefa(id);
            return Ok();
        }

        // Pesquisa tarefas pelo nome ou descrição
        [HttpGet("{filtro}")]
        public IActionResult PesquisarTarefas(string filtro)
        {
            List<Tarefa> tarefas = _gerenciador.PesquisarTarefas(filtro);
            return Ok(tarefas);
        }

        // Define a prioridade de uma tarefa pelo seu ID
        [HttpPut("{id}/prioridade")]
        public IActionResult DefinirPrioridade(int id, [FromBody] int prioridade)
        {
            _gerenciador.DefinirPrioridade(id, prioridade);
            return Ok();
        }

        // Atualiza o status de uma tarefa pelo seu ID
        [HttpPut("{id}/status")]
        public IActionResult AtualizarTarefa(int id, [FromBody] string status)
        {
            try
            {
                _gerenciador.AtualizarTarefaStatus(id, status);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest($"Ocorreu um erro ao atualizar o status da tarefa: {ex.Message}");
            }
        }
    }
}
